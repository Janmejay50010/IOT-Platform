import action_api
import sys

action_api.send_email(sys.argv[1])
